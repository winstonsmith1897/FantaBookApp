package middleware.dao;

public class UserDAOImplTest {
}
