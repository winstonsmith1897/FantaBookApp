package middleware.dao;

public class SquadDAOImplTest {
}
