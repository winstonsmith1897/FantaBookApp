package middleware.dao;


import com.google.common.annotations.VisibleForTesting;
import com.mongodb.MongoException;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;

import middleware.entities.*;
import middleware.exception.ActionNotCompletedException;
import middleware.log.UMLogger;
import middleware.persistence.mongoconnection.*;
import middleware.persistence.mongoconnection.Collections;
import middleware.persistence.neo4jconnection.Neo4jDriver;
import javafx.util.Pair;
import org.apache.log4j.Logger;
import org.bson.BsonType;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.neo4j.driver.Result;
import org.neo4j.driver.Session;
import org.neo4j.driver.TransactionWork;
import org.neo4j.driver.exceptions.Neo4jException;

import java.time.LocalDate;
import java.util.*;

import static com.mongodb.client.model.Accumulators.sum;
import static com.mongodb.client.model.Aggregates.*;
import static com.mongodb.client.model.Filters.*;
import static com.mongodb.client.model.Projections.*;
import static com.mongodb.client.model.Sorts.ascending;
import static com.mongodb.client.model.Sorts.descending;
import static com.mongodb.client.model.Updates.inc;

import static org.neo4j.driver.Values.parameters;


public class PlayerDAOImpl implements PlayerDAO {
    private static final Logger logger = UMLogger.getPlayerLogger();


    //-----------------------------------------------  CREATE  -----------------------------------------------


    @Override
    public void createPlayer(Player player) throws ActionNotCompletedException {

        if (player == null || player.getID() == null)
            throw new IllegalArgumentException();

        try {
            createPlayerDocument(player);
            createPlayerNode(player);
            logger.info("Created player <" + player.getID() + ">");

        } catch (MongoException mongoEx) {
            logger.error(mongoEx.getMessage());
            throw new ActionNotCompletedException(mongoEx);
        } catch (Neo4jException neoEx) {
            logger.error(neoEx.getMessage());
            try {
                deletePlayerDocument(player);
                throw new ActionNotCompletedException(neoEx);
            } catch (MongoException mongoEx) {
                logger.error(mongoEx.getMessage());
                throw new ActionNotCompletedException(mongoEx);
            }
        }
    }



    /**
     * Add a player document in MongoDb.
     *
     * @param player the player you want to add to mongoDb.
     * @throws MongoException when the database write fails.
     */
    private void createPlayerDocument(Player player) throws MongoException {

        MongoCollection<Document> playerCollection = MongoDriver.getInstance().getCollection(Collections.PLAYERS);
        //System.out.println(playerCollection);

        Document playerDocument = player.toBsonDocument();
        //System.out.println(playerDocument);

        //System.out.println("------------------------------------------------------------------");
        playerCollection.insertOne(playerDocument);
        //System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");

    }

    /**
     * Add a player node in Neo4j.
     *
     * @param player the player you want to add to Neo4j.
     * @throws Neo4jException when the database write fails.
     */
    private void createPlayerNode(Player player) throws Neo4jException {

        try (Session session = Neo4jDriver.getInstance().getDriver().session()) {
            session.writeTransaction((TransactionWork<Void>) tx -> {

                tx.run("CREATE (p:Player {playerId: $playerId, name: $name, team: $team," +
                                " imageUrl: $imageUrl, position: $position})",
                        parameters("playerId", player.getID(), "name", player.getName(),
                                "team", player.getTeam(), "imageUrl", player.getImageUrl(), "position", player.getPosition()));
                return null;
            });
        }
    }

    //----------------------------------------------  RETRIEVE  ----------------------------------------------


    /**
     * @param playerID the id of the player you want to to return.
     * @return the player with the specified id.
     */
    @Override
    public Player getPlayerById(String playerID) {

        MongoCollection<Document> playerCollection = MongoDriver.getInstance().getCollection(Collections.PLAYERS);
        Player playerToReturn = null;

        try (MongoCursor<Document> cursor = playerCollection.find(eq("_id", playerID)).iterator()) {
            if (cursor.hasNext()) {
                playerToReturn = new Player(cursor.next());
            }
        } catch (MongoException mongoEx) {
            logger.error(mongoEx.getMessage());
        }
        return playerToReturn;
    }


    /**
     * @param partialInput   the partial input of the user.
     * @param maxNumber      the max number of player you want to return.
     * @param attributeField the document's attribute you want to match.
     * @return players where the specified attribute fields contains the partial input of the user (case insensitive).
     * @throws ActionNotCompletedException when a database error occurs.
     */
    @VisibleForTesting
    public List<Player> filterPlayer(String partialInput, int maxNumber, String attributeField) throws ActionNotCompletedException {

        if (attributeField == null || maxNumber <= 0)
            throw new IllegalArgumentException();

        MongoCollection<Document> playerCollection = MongoDriver.getInstance().getCollection(Collections.PLAYERS);
        List<Player> playersToReturn = new ArrayList<>();

        String capitalPartialInput = partialInput.substring(0, 1).toUpperCase() + partialInput.substring(1);

        Bson match = match(regex(attributeField, "^" + capitalPartialInput + ".*"));
        Bson sortLike = sort(descending("likeCount"));
        try (MongoCursor<Document> cursor = playerCollection.aggregate(Arrays.asList(match, sortLike, limit(maxNumber))).iterator()) {
            while (cursor.hasNext()) {
                playersToReturn.add(new Player(cursor.next()));
            }
        } catch (MongoException mongoEx) {
            logger.error(mongoEx.getMessage());
            throw new ActionNotCompletedException(mongoEx);
        }
        return playersToReturn;
    }

    @Override
    public List<Pair<Integer, Pair<Player, Double>>> findTopRatedPlayerPerPosition() throws ActionNotCompletedException {
        return null;
    }



    /*
    @Override
    public List<player> getplayersByPartialAlbum(String partialAlbum, int limit) throws ActionNotCompletedException {
        return filterplayer(partialAlbum, limit, "album.title");
    }

    @Override
    public List<player> getplayersByPartialAlbum(String partialAlbum) throws ActionNotCompletedException {
        return getplayersByPartialAlbum(partialAlbum, 20);
    }

    @Override
    public List<player> getplayersByPartialTitle(String partialTitle, int limit) throws ActionNotCompletedException {
        return filterplayer(partialTitle, limit, "title");
    }

    @Override
    public List<player> getplayersByPartialTitle(String partialTitle) throws ActionNotCompletedException {
        return getplayersByPartialTitle(partialTitle, 20);
    }

    @Override
    public List<player> getplayersByPartialArtist(String partialArtist, int limit) throws ActionNotCompletedException {
        return filterplayer(partialArtist, limit, "artist");
    }

    @Override
    public List<player> getplayersByPartialArtist(String partialArtist) throws ActionNotCompletedException {
        return getplayersByPartialArtist(partialArtist, 20);
    }


     */

    /*

    @Override
    public List<Pair<Integer, Pair<Player, Double>>> findTopRatedPlayerPerPosition() throws ActionNotCompletedException {

        MongoCollection<Document> playerCollection = MongoDriver.getInstance().getCollection(Collections.PLAYERS);
        List<Pair<Integer, Pair<Player, Double>>> topAlbums = new ArrayList<>();

        Document computeExpression = Document.parse("{$multiply: [{ $floor:{ $divide: [ \"$releaseYear\", 10 ] }}, 10]}");

        Bson match = match(and(exists("releaseYear"), type("album.title", BsonType.STRING)));
        Bson project = project(fields(excludeId(), include("releaseYear"), include("album"), include("rating"), computed("decade", computeExpression)));

        Bson group = Document.parse("{$group: {_id: {title: \"$album.title\", url:\"$album.image\",  decade: \"$decade\"}, avgRating: {$avg: \"$rating\"}, numplayer:{$sum:1}}}");
        Bson match2 = match(gte("numplayer", 5));
        Bson sortRate = sort(ascending("avgRating"));

        Bson group2 = Document.parse("{$group:{" +
                "_id: \"$_id.decade\"," +
                "topAlbumTitle: {$last: \"$_id.title\"}," +
                "topAlbumUrl: {$last: \"$_id.url\"}," +
                "avgRating:{$last: \"$avgRating\"}" +
                "}}");
        Bson sortId = sort(ascending("_id"));
        Bson project2 = project(fields(excludeId(), computed("decade", "$_id"), include("topAlbumTitle"),  include("avgRating"), include("topAlbumUrl")));

        try (MongoCursor<Document> cursor = playerCollection.aggregate(Arrays.asList(match, project, group, match2, sortRate, group2, sortId, project2)).iterator()){
            while(cursor.hasNext()) {
                Document record = cursor.next();

                Player playerToAdd = new Player(); albumToAdd.setTitle(record.getString("topAlbumTitle")); albumToAdd.setImage(record.getString("topAlbumUrl"));

                int decade = record.getDouble("decade").intValue();

                double avgRating = record.getDouble("avgRating");

                Pair<Integer, Pair<Album, Double>> resultToAdd= new Pair<>(decade, new Pair<>(albumToAdd, avgRating));
                topAlbums.add(resultToAdd);
            }
        } catch (MongoException mongoEx) {
            logger.error(mongoEx.getMessage());
            throw new ActionNotCompletedException(mongoEx);
        }
        return topAlbums;
    }


     */



    @Override
    public List<Pair<String, Integer>> findPlayersWithMostNumberOfGoal(int golLimit, int maxNumber) throws ActionNotCompletedException {

        if (maxNumber <= 0)
            throw new IllegalArgumentException();

        MongoCollection<Document> playerCollection = MongoDriver.getInstance().getCollection(Collections.PLAYERS);

        List<Pair<String, Integer>> playerRank = new ArrayList<>();

        Bson match = match(gte("likeCount", golLimit));
        Bson group = group("$player", sum("numberOfGoals", 1));
        Bson sortHits = sort(descending("numberOfGoals"));
        Bson limit = limit(maxNumber);
        Bson project = project(fields(excludeId(), computed("player", "$_id"), include("numberOfGoals")));
        try (MongoCursor<Document> cursor = playerCollection.aggregate(Arrays.asList(match, group, sortHits, limit, project)).iterator()) {
            while (cursor.hasNext()) {
                Document player = cursor.next();
                playerRank.add(new Pair<>(player.getString("player"), player.getInteger("numberOfGoals")));
            }
        } catch (MongoException mongoEx) {
            logger.error(mongoEx.getMessage());
            throw new ActionNotCompletedException(mongoEx);
        }
        return playerRank;
    }


    @Override
    public List<Player> getBestPlayers(int limit) throws ActionNotCompletedException {

        List<Player> bestPlayers = new ArrayList<>();

        try (Session session = Neo4jDriver.getInstance().getDriver().session()) {
            session.writeTransaction((TransactionWork<List<Player>>) tx -> {

                LocalDate lastMonth = LocalDate.now().minusDays(30);

                String query = "MATCH (s:player)<-[l:LIKES]-(u:User) " +
                        "WHERE l.day > date($lastMonth) " +
                        "WITH s, COUNT(*) as num ORDER BY num DESC " +
                        "RETURN s.playerId as playerId, s.title as title, s.artist as artist, s.imageUrl as imageUrl " +
                        "LIMIT $limit";

                Result result = tx.run(query, parameters("lastMonth", lastMonth.toString(), "limit", limit));
                while (result.hasNext()) {
                    bestPlayers.add(new Player(result.next()));
                }
                return bestPlayers;
            });
        } catch (Neo4jException neoEx) {
            logger.error(neoEx.getMessage());
            throw new ActionNotCompletedException(neoEx);
        }
        return bestPlayers;
    }


    //-----------------------------------------------  UPDATE  -----------------------------------------------



    @Override
    public void incrementLikeCount(Player player) throws ActionNotCompletedException {

        if (player == null || player.getID() == null)
            throw new IllegalArgumentException();

        MongoCollection<Document> playerCollection = MongoDriver.getInstance().getCollection(Collections.PLAYERS);
        try {
            playerCollection.updateOne(eq("_id", player.getID()), inc("likeCount", 1));
            player.setLikeCount(player.getLikeCount() + 1);
        } catch (MongoException mongoEx) {
            logger.error(mongoEx.getMessage());
            throw new ActionNotCompletedException(mongoEx);
        }

    }


    @Override
    public void decrementLikeCount(Player player) throws ActionNotCompletedException {

        if (player == null || player.getID() == null)
            throw new IllegalArgumentException();

        MongoCollection<Document> playerCollection = MongoDriver.getInstance().getCollection(Collections.PLAYERS);
        try {
            playerCollection.updateOne(eq("_id", player.getID()), inc("likeCount", -1));
            player.setLikeCount(player.getLikeCount() - 1);
        } catch (MongoException mongoEx) {
            logger.error(mongoEx.getMessage());
            throw new ActionNotCompletedException(mongoEx);
        }
    }




    @Override
    public int getTotalPlayers() {
        try (Session session = Neo4jDriver.getInstance().getDriver().session()) {
            return session.readTransaction((TransactionWork<Integer>) tx -> {

                Result result = tx.run("MATCH (:player) RETURN COUNT(*) AS NUM");
                if (result.hasNext())
                    return result.next().get("NUM").asInt();
                else
                    return -1;
            });

        } catch (Neo4jException neo4) {
            neo4.printStackTrace();
            return -1;
        }
    }

    //-----------------------------------------------  DELETE  -----------------------------------------------


    @Override
    public void deletePlayer(Player player) throws ActionNotCompletedException, IllegalArgumentException {
        if (player == null) throw new IllegalArgumentException();

        try {
            deletePlayerDocument(player);
            deletePlayerNode(player);
            logger.info("DELETED Player " + player.getID());
        } catch (MongoException | Neo4jException mEx) {
            logger.error(mEx.getMessage());
            throw new ActionNotCompletedException(mEx);
        }
    }

    @Override
    public void deletePlayerDocument(Player player) throws MongoException {
        MongoCollection<Document> playerColl = MongoDriver.getInstance().getCollection(Collections.PLAYERS);
        playerColl.deleteOne(eq("_id", player.getID()));
    }

    private void deletePlayerNode(Player player) throws Neo4jException {
        try (Session session = Neo4jDriver.getInstance().getDriver().session()) {
            session.writeTransaction((TransactionWork<Void>) tx -> {

                tx.run("MATCH (s:player {playerId: $playerId})"
                                + "DETACH DELETE s",
                        parameters("playerId", player.getID()));
                return null;
            });
        }
    }
}


