package databasePopulation;

import com.mongodb.MongoException;
import com.mongodb.client.*;

import static com.mongodb.client.model.Aggregates.match;

import com.mongodb.MongoException;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import frontend.MiddlewareConnector;
import middleware.dao.*;
import middleware.entities.*;
import middleware.exception.ActionNotCompletedException;
import middleware.persistence.mongoconnection.Collections;
import middleware.persistence.mongoconnection.MongoDriver;
import middleware.persistence.neo4jconnection.Neo4jDriver;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.neo4j.driver.Result;
import org.neo4j.driver.Session;
import org.bson.Document;

import org.neo4j.driver.TransactionWork;
import org.neo4j.driver.exceptions.Neo4jException;
import org.neo4j.driver.exceptions.NoSuchRecordException;

import javax.print.Doc;
import java.time.Year;
import java.util.*;
import java.util.function.Consumer;

import static com.mongodb.client.model.Aggregates.sample;
import static com.mongodb.client.model.Filters.*;
import static org.neo4j.driver.Values.parameters;

public class UserPopulation {

    private static final MiddlewareConnector connector = MiddlewareConnector.getInstance();


    public static void main(String[] args) throws ActionNotCompletedException {
        populateWithUser(10);
    }
    private static void populateWithUser(int howManyUsers) throws ActionNotCompletedException {
        Random generator = new Random();

        String[] firstName =  new String[] {"Emily","Hannah","Madison","Ashley","Sarah","Alexis","Samantha","Jessica","Elizabeth","Taylor","Lauren","Alyssa","Kayla","Abigail","Brianna","Olivia","Emma","Megan","Grace","Victoria","Rachel","Anna","Sydney","Destiny","Morgan","Jennifer","Jasmine","Haley","Julia","Kaitlyn","Nicole","Amanda","Katherine","Natalie","Hailey","Alexandra","Adam", "Alex", "Aaron", "Ben", "Carl", "Dan", "David", "Edward", "Fred", "Frank", "George", "Hal", "Hank", "Ike", "John", "Jack", "Joe", "Larry", "Monte", "Matthew", "Mark", "Nathan", "Otto", "Paul", "Peter", "Roger", "Roger", "Steve", "Thomas", "Tim", "Ty", "Victor", "Walter", "Alessio", "Valerio", "Lorenzo", "Giacomo", "Marco", "Mario", "Salvatore"};

        String[] lastName = new String[] {"Anderson", "Ashwoon", "Aikin", "Bateman", "Bongard", "Bowers", "Boyd", "Cannon", "Cast", "Deitz", "Dewalt", "Ebner", "Frick", "Hancock", "Haworth", "Hesch", "Hoffman", "Kassing", "Knutson", "Lawless", "Lawicki", "Mccord", "McCormack", "Miller", "Myers", "Nugent", "Ortiz", "Orwig", "Ory", "Paiser", "Pak", "Pettigrew", "Quinn", "Quizoz", "Ramachandran", "Resnick", "Sagar", "Schickowski", "Schiebel", "Sellon", "Severson", "Shaffer", "Solberg", "Soloman", "Sonderling", "Soukup", "Soulis", "Stahl", "Sweeney", "Tandy", "Trebil", "Trusela", "Trussel", "Turco", "Uddin", "Uflan", "Ulrich", "Upson", "Vader", "Vail", "Valente", "Van Zandt", "Vanderpoel", "Ventotla", "Vogal", "Wagle", "Wagner", "Wakefield", "Weinstein", "Weiss", "Woo", "Yang", "Yates", "Yocum", "Zeaser", "Zeller", "Ziegler", "Bauer", "Baxster", "Casal", "Cataldi", "Caswell", "Celedon", "Serra", "Giannini", "Binchi", "Rossi", "Chambers", "Chapman", "Christensen", "Darnell", "Davidson", "Davis", "DeLorenzo", "Dinkins", "Doran", "Dugelman", "Dugan", "Duffman", "Eastman", "Ferro", "Ferry", "Fletcher", "Fietzer", "Hylan", "Hydinger", "Illingsworth", "Ingram", "Irwin", "Jagtap", "Jenson", "Johnson", "Johnsen", "Jones", "Jurgenson", "Kalleg", "Kaskel", "Keller", "Leisinger", "LePage", "Lewis", "Linde", "Lulloff", "Maki", "Martin", "McGinnis", "Mills", "Moody", "Moore", "Napier", "Nelson", "Norquist", "Nuttle", "Olson", "Ostrander", "Reamer", "Reardon", "Reyes", "Rice", "Ripka", "Roberts", "Rogers", "Root", "Sandstrom", "Sawyer", "Schlicht", "Schmitt", "Schwager", "Schutz", "Schuster", "Tapia", "Thompson", "Tiernan", "Tisler"};

        String[] countries = {"Afghanistan","Albania","Algeria","Andorra","Angola","Anguilla","Antigua-Barbuda","Argentina","Armenia","Aruba","Australia","Austria","Azerbaijan","Bahamas","Bahrain","Bangladesh","Barbados","Belarus","Belgium","Belize","Benin","Bermuda","Bhutan","Bolivia","Bosnia-Herzegovina","Botswana","Brazil","British Virgin Islands","Brunei","Bulgaria","Burkina Faso","Burundi","Cambodia","Cameroon","Cape Verde","Cayman Islands","Chad","Chile","China","Colombia","Congo","Cook Islands","Costa Rica","Cote D Ivoire","Croatia","Cruise Ship","Cuba","Cyprus","Czech Republic","Denmark","Djibouti","Dominica","Dominican Republic","Ecuador","Egypt","El Salvador","Equatorial Guinea","Estonia","Ethiopia","Falkland Islands","Faroe Islands","Fiji","Finland","France","French Polynesia","French West Indies","Gabon","Gambia","Georgia","Germany","Ghana","Gibraltar","Greece","Greenland","Grenada","Guam","Guatemala","Guernsey","Guinea","Guinea Bissau","Guyana","Haiti","Honduras","Hong Kong","Hungary","Iceland","India","Indonesia","Iran","Iraq","Ireland","Isle of Man","Israel","Italy","Jamaica","Japan","Jersey","Jordan","Kazakhstan","Kenya","Kuwait","Kyrgyz Republic","Laos","Latvia","Lebanon","Lesotho","Liberia","Libya","Liechtenstein","Lithuania","Luxembourg","Macau","Macedonia","Madagascar","Malawi","Malaysia","Maldives","Mali","Malta","Mauritania","Mauritius","Mexico","Moldova","Monaco","Mongolia","Montenegro","Montserrat","Morocco","Mozambique","Namibia","Nepal","Netherlands","Netherlands Antilles","New Caledonia","New Zealand","Nicaragua","Niger","Nigeria","Norway","Oman","Pakistan","Palestine","Panama","Papua New Guinea","Paraguay","Peru","Philippines","Poland","Portugal","Puerto Rico","Qatar","Reunion","Romania","Russia","Rwanda","Saint Pierre-Miquelon","Samoa","San Marino","Satellite","Saudi Arabia","Senegal","Serbia","Seychelles","Sierra Leone","Singapore","Slovakia","Slovenia","South Africa","South Korea","Spain","Sri Lanka","St Kitts-Nevis","St Lucia","St Vincent","St. Lucia","Sudan","Suriname","Swaziland","Sweden","Switzerland","Syria","Taiwan","Tajikistan","Tanzania","Thailand","Timor L'Este","Togo","Tonga","Trinidad-Tobago","Tunisia","Turkey","Turkmenistan","Turks-Caicos","Uganda","Ukraine","United Arab Emirates","United Kingdom","Uruguay","Uzbekistan","Venezuela","Vietnam","Virgin Islands (US)","Yemen","Zambia","Zimbabwe"};


        for(int i = 0; i < howManyUsers; i++){
            String fName = firstName[generator.nextInt(firstName.length)];
            String lName = lastName[generator.nextInt(lastName.length)];
            int age = generator.nextInt(57) + 18;
            String username;
            String password = "";
            for(int j = 0; j < 6; j++){
                password += (char) (generator.nextInt(26) + 'a');
            }
            password = Integer.toString(generator.nextInt(100));
            String country = countries[generator.nextInt(countries.length)];

            try {
                username = fName.substring(0, 3) + lName.substring(0, 3) + (Year.now().getValue() - age);
            }catch (IndexOutOfBoundsException index){
                continue;
            }
            User user = new User(username, password,fName, lName, age, country);

            UserDAOImpl userDAO = new UserDAOImpl();

            userDAO.createUser(user);
            System.out.println("-------------------------------RANDOM LIKE PLAYER------------------------");

            likeRandomPlayers(user, 5);

        }
        createRandomSquad(10, 3, 22);
        System.out.println("-------------------------------RANDOM LIKES------------------------");
        completelyRandomLikes(10);
        System.out.println("-------------------------------RANDOM FOLLOWS------------------------");
        completelyRandomSquadFollow(10);
        completelyRandomUserFollows(5);



        System.out.println("RESOLVE INCONSISTENCIES");
        resolveSquadInconsistencies();
        /*
        resolvePlayerInconsistencies();
        resolveUserInconsistencies();
        resolveNode();

         */
    }


    public static MongoCollection<Document> getRandomPlayer() throws ActionNotCompletedException {
        MongoCollection<Document> playersCollection = (MongoCollection<Document>) MongoDriver.getInstance().getCollection(Collections.PLAYERS);
        System.out.println(playersCollection.countDocuments());
        return playersCollection;
    }


    public static Player getRandomAttacker(MongoCollection<Document> playersCollection) throws ActionNotCompletedException{
        Player player = null;

        Bson sample = sample(6000);
        Bson match1 =  match(eq("position", "Centre-Forward"));
        Bson match2 = match(or(eq("league", "LaLiga"),
                eq("league", "Premier League"),
                eq("league", "Serie A"),
                eq("league", "Bundesliga"),
                eq("league", "Ligue 1")));


        try (MongoCursor<Document> cursor = playersCollection.aggregate(Arrays.asList(match1,
                match2,
                sample)).iterator()) {
            if(cursor.hasNext()) {
                player = new Player(cursor.next());
                System.out.println(player.getName());
            }
        }catch (MongoException mongoEx) {
            System.out.println(mongoEx.getMessage());
            throw new ActionNotCompletedException(mongoEx);
        }
        return player;
    }

    public static Player getRandomDefender(MongoCollection<Document> playersCollection) throws ActionNotCompletedException{
        Player player = null;

        Bson sample = sample(6000);
        Bson match1 =  match(or(eq("position", "Centre-Back"),
                eq("position", "Left-Back"),
                eq("position", "Right-Back")));
        Bson match2 = match(or(eq("league", "LaLiga"),
                eq("league", "Premier League"),
                eq("league", "Serie A"),
                eq("league", "Bundesliga"),
                eq("league", "Ligue 1")));


        try (MongoCursor<Document> cursor = playersCollection.aggregate(Arrays.asList(match1,
                match2,
                sample)).iterator()) {
            if(cursor.hasNext()) {
                player = new Player(cursor.next());
                System.out.println(player.getName());

            }
        }catch (MongoException mongoEx) {
            System.out.println(mongoEx.getMessage());
            throw new ActionNotCompletedException(mongoEx);
        }
        return player;
    }

    public static Player getRandomMidfielder(MongoCollection<Document> playersCollection) throws ActionNotCompletedException{
        Player player = null;

        Bson sample = sample(6000);
        Bson match1 =  match(or(eq("position", "DefensiveMidfield"),
                eq("position", "CentralMidfield"),
                eq("position", "AttackingMidfield"),
                eq("position", "LeftWinger"),
                eq("position", "RightWinger")));
        Bson match2 = match(or(eq("league", "LaLiga"),
                eq("league", "Premier League"),
                eq("league", "Serie A"),
                eq("league", "Bundesliga"),
                eq("league", "Ligue 1")));


        try (MongoCursor<Document> cursor = playersCollection.aggregate(Arrays.asList(match1,
                match2,
                sample)).iterator()) {
            if(cursor.hasNext()) {
                player = new Player(cursor.next());
                System.out.println(player.getName());

            }
        }catch (MongoException mongoEx) {
            System.out.println(mongoEx.getMessage());
            throw new ActionNotCompletedException(mongoEx);
        }
        return player;
    }

    public static Player getRandomGoalkeeper(MongoCollection<Document> playersCollection) throws ActionNotCompletedException{
        Player player = null;

        Bson sample = sample(6000);
        Bson match1 =  match(eq("position", "Goalkeeper"));
        Bson match2 = match(or(eq("league", "LaLiga"),
                eq("league", "Premier League"),
                eq("league", "Serie A"),
                eq("league", "Bundesliga"),
                eq("league", "Ligue 1")));


        try (MongoCursor<Document> cursor = playersCollection.aggregate(Arrays.asList(match1,
                match2,
                sample)).iterator()) {
            if(cursor.hasNext()) {
                player = new Player(cursor.next());
                System.out.println(player.getName());
            }
        }catch (MongoException mongoEx) {
            System.out.println(mongoEx.getMessage());
            throw new ActionNotCompletedException(mongoEx);
        }
        return player;
    }

    public static User getRandomUser() throws ActionNotCompletedException{
        MongoCollection<Document> usersCollection = MongoDriver.getInstance().getCollection(Collections.USERS);
        User user = null;

        Bson sample = sample(1);

        try (MongoCursor<Document> cursor = usersCollection.aggregate(Arrays.asList(sample)).iterator()) {
            if(cursor.hasNext()) {
                Document result = cursor.next();
                user = new User(result);
                System.out.println("\n\nChoosen Player\n\n");
                System.out.println(user.getUsername());
                System.out.println("\n\nFINE\n\n");

            }
        }catch (MongoException mongoEx) {
            System.out.println(mongoEx.getMessage());
            throw new ActionNotCompletedException(mongoEx);
        }

        return user;
    }

    //select some random users and add random number of squad to them, with a random number of random players
    public static void createRandomSquad(int numUsers, int maxNumSquadsPerUser, int maxNumPlayersPerSquads) throws ActionNotCompletedException{
        Random random = new Random();
        //maxNumPlayersPerSquads = 11;
        for (int i = 0; i < numUsers; i++){
            User user = getRandomUser();
            System.out.println(user.getUsername());
            int numSquads = random.nextInt(maxNumSquadsPerUser);
            for (int j = 0; j < numSquads; j++){
                int current_position = random.nextInt(22);
                Squad squad = new Squad(user.getUsername(), "Squad " + (j + 1) + " by " + user.getFirstName());
                squad.setCurrent_position(current_position);
                MongoCollection<Document> playersList = getRandomPlayer(); // MongoDriver.getInstance().getCollection(Collections.PLAYERS);;
                System.out.println(playersList.countDocuments());
                Bson sample = sample(1000);
                Player player = null;
                try (MongoCursor<Document> cursor = playersList.aggregate(Arrays.asList(sample)).iterator()) {
                    if(cursor.hasNext()) {
                        player = new Player(cursor.next());
                    }
                }catch (MongoException mongoEx) {
                    System.out.println(mongoEx.getMessage());
                    throw new ActionNotCompletedException(mongoEx);
                }
                squad.setUrlImage(player.getImageUrl());
                connector.createSquad(squad);
                addRandomPlayers(squad, maxNumPlayersPerSquads);

            }
        }
    }

    public static PlayerDAOImpl addRandomPlayers(Squad squad, int numPlayers) throws ActionNotCompletedException{
        MongoCollection<Document> playersList = getRandomPlayer();
        System.out.println(playersList.countDocuments());
        int i;
        Player player = null;
        Player defender = null;
        Player midfielder = null;
        Player attacker = null;
        for (i = 0; i < numPlayers; i++){
            if (i <  3) {
                player = getRandomGoalkeeper(playersList);
                System.out.println(player.getName());
                System.out.println(player.getPosition());
                System.out.println("***********************************************++++");
                connector.addPlayer(squad, player);
            }
            else if (2 < i && i < 9) {
                defender = getRandomDefender(playersList);
                System.out.println(defender.getName());
                System.out.println(defender.getPosition());
                System.out.println(defender.getLeague());
                System.out.println("***********************************************++++");
                connector.addPlayer(squad, defender);
            }
            else if (8 < i  && i < 16) {
                midfielder = getRandomMidfielder(playersList);
                System.out.println(midfielder.getName());
                System.out.println(midfielder.getPosition());
                System.out.println("***********************************************++++");
                connector.addPlayer(squad, midfielder);
            }
            else if (15 < i && i < 22) {
                attacker = getRandomAttacker(playersList);
                System.out.println(attacker.getName());
                System.out.println(attacker.getPosition());
                System.out.println("***********************************************++++");
                connector.addPlayer(squad, attacker);
            }
        }
        return null;
    }

    //put some likes to random players from a user
    public static void likeRandomPlayers(User user, int numLikes) throws ActionNotCompletedException{
        UserDAO userDao = new UserDAOImpl();
        MongoCollection<Document> playersList = getRandomPlayer();
        for (int i = 0; i < numLikes; i++)
            if (i < 4)
            userDao.likePlayer(user, getRandomGoalkeeper(playersList));
            else if (i > 4 && i < 10)
                userDao.likePlayer(user, getRandomDefender(playersList));
            else if (i > 4 && i < 20)
                userDao.likePlayer(user, getRandomMidfielder(playersList));
            else if (i > 4 && i < 100)
                userDao.likePlayer(user, getRandomAttacker(playersList));
    }

    //put some likes to random players from random users
    public static void completelyRandomLikes(int numLikes) throws ActionNotCompletedException {
        UserDAO userDao = new UserDAOImpl();
        MongoCollection<Document> playersList = getRandomPlayer();
        for (int i = 0; i < numLikes; i++) {
            if (i < 4)
                userDao.likePlayer(getRandomUser(), getRandomGoalkeeper(playersList));
            else if (i > 4 && i < 10)
                userDao.likePlayer(getRandomUser(), getRandomDefender(playersList));
            else if (i > 4 && i < 20)
                userDao.likePlayer(getRandomUser(), getRandomMidfielder(playersList));
            else if (i > 4 && i < 100)
                userDao.likePlayer(getRandomUser(), getRandomAttacker(playersList));
        }

    }

    public static void completelyRandomUserFollows(int numFollows) throws ActionNotCompletedException {
        UserDAO userDAO = new UserDAOImpl();

        for (int i = 0; i < numFollows; i++) {
            userDAO.followUser(getRandomUser(), getRandomUser());

        }
    }

    public static Squad getRandomSquad() throws NoSuchRecordException {
        Squad squad;
        try ( Session session = Neo4jDriver.getInstance().getDriver().session() )
        {
         System.out.println(session);

            squad = session.readTransaction((TransactionWork<Squad>) tx -> {
                Result result = tx.run(     "MATCH (p:Squad) \n" +
                        "RETURN p, rand() as r\n" +
                        "ORDER BY r\n" +
                        "LIMIT 1;");
                return new Squad(result.next().get("p"));
            });
        }
        return squad;
    }

    public static void completelyRandomSquadFollow(int numFollow) throws ActionNotCompletedException{
        UserDAO userDAO = new UserDAOImpl();
        for (int i = 0; i < numFollow; i++)
            userDAO.followSquad(getRandomUser(), getRandomSquad());
    }

    private static void resolvePlayerInconsistencies() {

        MongoCollection<Document> playerCollection = MongoDriver.getInstance().getCollection(Collections.PLAYERS);
        PlayerDAO playerDAO = new PlayerDAOImpl();
        try (MongoCursor<Document> cursor = playerCollection.find().iterator()) {
            while (cursor.hasNext()) {
                Player mongoPlayer = new Player(cursor.next());
                try (Session session = Neo4jDriver.getInstance().getDriver().session()) {
                    String query = "MATCH (s:Player) " +
                            "WHERE s.playerId = $playerId " +
                            "RETURN s.playerId as playerId " ;
                    Result result = session.run(query, parameters("playerId", mongoPlayer.getID()));

                    if(!result.hasNext()){
                        System.out.println("Sure to delete id: " + mongoPlayer.getID());
                        System.out.print("> ");
                        String response = new Scanner(System.in).nextLine();
                        if(response.equals("yes"))
                            playerDAO.deletePlayerDocument(mongoPlayer);
                        else
                            System.out.println("Not deleted");
                    }
                }
            }
        }
    }

        private static void resolveNode() throws ActionNotCompletedException {
            try (Session session = Neo4jDriver.getInstance().getDriver().session()) {
                Result result = session.run("MATCH (u:User) RETURN u.username AS username");
                UserDAO userDAO = new UserDAOImpl();
                while(result.hasNext()) {
                    System.out.println("O");
                    String username = result.next().get("username").asString();
                    User user = userDAO.getUserByUsername(username);
                    if (user == null) {
                        user = new User(username);
                        //userDAO.deleteUserNode(user);
                        System.out.println("cancellato");
                    }
                }
            }catch (Neo4jException neo4){
                neo4.printStackTrace();
            }
        }

    private static void resolveSquadInconsistencies() throws ActionNotCompletedException {

        MongoCollection<Document> userCollection = MongoDriver.getInstance().getCollection(Collections.USERS);
        System.out.println("COUNT USERS");
        System.out.println(userCollection.countDocuments());
        SquadDAO squadDAO = new SquadDAOImpl();
        try (MongoCursor<Document> cursor = userCollection.find().iterator()) {
            int count = 0;
            while (cursor.hasNext()) {
                ++count;
                System.out.println("\n\n" + count + "\n\n");
                Squad mongoSquad = new Squad(cursor.next());
                System.out.println("\n\n----------------------------------------\n\n");
                System.out.println(mongoSquad.getID());
                try (Session session = Neo4jDriver.getInstance().getDriver().session()) {
                    String query = "MATCH (p:Squad) " +
                            "WHERE p.squadId = $squadId " +
                            "RETURN p.squadId"; //as p.squadId " ;
                    Result result = session.run(query, parameters("squadId", mongoSquad.getID()));
                    System.out.println("RESULT");
                    System.out.println(result);

                    if(!result.hasNext()){
                        System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                        System.out.println(mongoSquad.getID());
                        //System.out.println("Sure to delete id: " + mongoSquad.getID());
                        //System.out.print("> yes");
                        //String response = new Scanner(System.in).nextLine();
                        //if(response.equals("yes"))
                        //squadDAO.deleteSquadDocument(mongoSquad);
                        //else
                        //    System.out.println("Not deleted");


                    }
                }
            }
        }
    }

    private static void resolveUserInconsistencies() {

        MongoCollection<Document> playerCollection = MongoDriver.getInstance().getCollection(Collections.USERS);
        UserDAO userDAO = new UserDAOImpl();
        try (MongoCursor<Document> cursor = playerCollection.find().iterator()) {
            while (cursor.hasNext()) {
                User mongoUser = new User(cursor.next());
                try (Session session = Neo4jDriver.getInstance().getDriver().session()) {
                    String query = "MATCH (u:User) " +
                            "WHERE u.username = $username " +
                            "RETURN u.username as username " ;
                    Result result = session.run(query, parameters("username", mongoUser.getUsername()));

                    if(!result.hasNext()){
                        System.out.println("Sure to delete id: " + mongoUser.getUsername());
                        userDAO.deleteUserDocument(mongoUser);
                        System.out.println("deleted");
                    }
                }
            }
        }
    }

}