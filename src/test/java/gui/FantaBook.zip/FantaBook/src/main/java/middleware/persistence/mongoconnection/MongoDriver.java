package middleware.persistence.mongoconnection;

import com.mongodb.ConnectionString;
import com.mongodb.client.*;

import java.util.Set;

public class MongoDriver {
    private static final MongoDriver instance = new MongoDriver();
    private final MongoClient client;
    private final MongoDatabase mongoDB;

    private final String databaseName = "FantaBook";

    MongoDriver() {
        String connectionString;
        //172.16.3.223:27020,172.16.3.224:27020,
        connectionString = "mongodb://172.16.4.223:27020,172.16.4.224:27020,172.16.4.225:27020/"
                + "?w=1&readPreference=nearest";
        client = MongoClients.create(new ConnectionString(connectionString));
        //System.out.println("Connected Successfully");
        // connect with the database

        mongoDB = client.getDatabase(databaseName);
        /*
        MongoIterable<String> cols = client.listDatabaseNames();

        for (String s : cols) {
            System.out.println(s);
        }

         */
        //System.out.println(mongoDB);


    }

    public static MongoDriver getInstance() { return instance; }

    public MongoCollection getCollection(Collections collectionName) {
        return mongoDB.getCollection(collectionName.toString());
    }

    public void closeConnection() { client.close(); }
}