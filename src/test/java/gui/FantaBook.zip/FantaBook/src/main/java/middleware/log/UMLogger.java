package middleware.log;

import middleware.dao.SquadDAOImpl;
import middleware.dao.PlayerDAOImpl;
import middleware.dao.UserDAOImpl;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class UMLogger {
    private static UMLogger umLogger = new UMLogger();

    private static final String LOG_FILE = "D:\\FantaBook\\src\\main\\resources\\log4j.properties";

    private static final Logger userLogger = Logger.getLogger(UserDAOImpl.class);
    private static final Logger playerLogger = Logger.getLogger(PlayerDAOImpl.class);
    private static final Logger squadLogger = Logger.getLogger(SquadDAOImpl.class);

    private UMLogger() {
        try {
            Properties loggerProperties = new Properties();
            loggerProperties.load(new FileReader(LOG_FILE));
            PropertyConfigurator.configure(loggerProperties);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static Logger getUserLogger(){
        return userLogger;
    }

    public static Logger getPlayerLogger(){
        return playerLogger;
    }

    public static Logger getSquadLogger(){
        return squadLogger;
    }
}