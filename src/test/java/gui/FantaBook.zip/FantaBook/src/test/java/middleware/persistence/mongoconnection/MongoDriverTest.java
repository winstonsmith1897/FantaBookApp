package middleware.persistence.mongoconnection;

import middleware.persistence.mongoconnection.MongoDriver;
import com.mongodb.ConnectionString;
import com.mongodb.client.*;

import org.junit.jupiter.api.Test;

public class MongoDriverTest {
    private static final MongoDriver instance = new MongoDriver();
    private final MongoClient client;
    private final MongoDatabase mongoDB;

    private final String databaseName = "FantaBook";

    private MongoDriverTest() {
        String connectionString = "mongodb://172.16.3.223:27020,172.16.3.224:27020,172.16.3.225:27020/"
                + "?w=1&readPreference=nearest";
        client = MongoClients.create(new ConnectionString(connectionString));
        // connect with the
        System.out.println("Successful");
        mongoDB = client.getDatabase(databaseName);
    }
    @Test
    public static MongoDriver getInstance() { return instance; }
    @Test
    public MongoCollection getCollection(Collections collectionName) {
        collectionName = Collections.PLAYERS;
        return mongoDB.getCollection(collectionName.toString());
    }
    @Test
    public void closeConnection() { client.close(); }
}
